<?php

use yii\helpers\Html;

?>

<h1><?= Html::encode($message) ?></h1>